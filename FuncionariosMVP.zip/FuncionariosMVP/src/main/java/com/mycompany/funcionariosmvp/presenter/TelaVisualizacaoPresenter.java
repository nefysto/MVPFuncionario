/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.funcionariosmvp.presenter;

import com.mycompany.funcionariosmvp.collection.FuncionarioCollection;
import com.mycompany.funcionariosmvp.model.Funcionario;
import com.mycompany.funcionariosmvp.view.TelaInclusaoView;
import com.mycompany.funcionariosmvp.view.TelaVisualizacaoView;

/**
 *
 * @author Alexandre
 */
/*public class TelaVisualizacaoPresenter {
    private FuncionarioCollection collection;
    private Funcionario funcionario;
    private TelaConsultaPresenter telaConsultaPresenter;
    private TelaInclusaoView telaInclusaoView;
    
    public TelaVisualizacaoPresenter(TelaInclusaoView telaInclusaoView, FuncionarioCollection collection){
        this.collection = collection;
        this.funcionario = funcionario;
        this.telaInclusaoView = telaInclusaoView;
        this.telaInclusaoView.setVisible(false);
        janelaResultado();
    }

    public void iniciar() {
        // Obter o funcionário selecionado da tela de consulta
        this.funcionario = this.telaConsultaPresenter.getTelaConsultaView().getFuncionarioSelecionado();

        // Carregar as informações do funcionário na tela de visualização
        telaVisualizacaoView().setjTextFieldNome(this.funcionario.getNome());
        this.telaVisualizacaoView.setNome(this.funcionario.getNome());
        this.telaVisualizacaoView.setCpf(this.funcionario.getCpf());
        this.telaVisualizacaoView.setCargo(this.funcionario.getCargo());
        this.telaVisualizacaoView.setSalario(this.funcionario.getSalario());

        // Desabilitar os campos da tela de visualização
        this.tela.getNome().setEditable(false);
        this.tela.getCpf().setEditable(false);
        this.tela.getCargo().setEditable(false);
        this.tela.getSalario().setEditable(false);
    
    
    public void janelaResultado(){
        this.telaInclusaoView.setVisible(true);
        this.telaInclusaoView.getjTextFieldNome().setEditable(false);
        this.telaInclusaoView.getjTextFieldCargo().setEditable(false);
        this.telaInclusaoView.getjTextFieldSalario().setEditable(false);
        this.telaInclusaoView.getjTextFieldNome().setText(funcionario.getNome());
        this.telaInclusaoView.getjTextFieldCargo().setText(funcionario.getCargo());
        this.telaInclusaoView.getjTextFieldSalario().setText(Double.toString(funcionario.getSalario()));
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public FuncionarioCollection getCollection() {
        return collection;
    }

    public void setCollection(FuncionarioCollection collection) {
        this.collection = collection;
    }

    public TelaConsultaPresenter getTelaConsultaPresenter() {
        return telaConsultaPresenter;
    }

    public void setTelaConsultaPresenter(TelaConsultaPresenter telaConsultaPresenter) {
        this.telaConsultaPresenter = telaConsultaPresenter;
    }

    public TelaInclusaoView getTelaInclusaoView() {
        return telaInclusaoView;
    }

    public void setTelaInclusaoView(TelaInclusaoView telaInclusaoView) {
        this.telaInclusaoView = telaInclusaoView;
    }

}
}*/
