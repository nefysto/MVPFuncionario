/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.funcionariosmvp.presenter;

import com.mycompany.funcionariosmvp.collection.FuncionarioCollection;
import com.mycompany.funcionariosmvp.model.Funcionario;
import com.mycompany.funcionariosmvp.view.TelaConsultaView;
import com.mycompany.funcionariosmvp.view.TelaInclusaoView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

public class TelaConsultaPresenter {
    private FuncionarioCollection collection;
    private TelaConsultaView telaConsultaView;
    //private TelaVisualizacaoPresenter telaVisualizacaoPresenter;
    
    public TelaConsultaPresenter(TelaConsultaView telaConsultaView, FuncionarioCollection collection){
        this.collection = collection;
        this.telaConsultaView = telaConsultaView;
        configuraTabela(collection);
        this.telaConsultaView.setVisible(false);
        //telaVisualizacaoPresenter = new TelaVisualizacaoPresenter(new TelaInclusaoView(), collection);
        //telaVisualizacaoPresenter.getTelaInclusaoView().setVisible(false);
        cancelarOperacao();
    }

    public FuncionarioCollection getCollection() {
        return collection;
    }

    public TelaConsultaView getTelaConsultaView() {
        return telaConsultaView;
    }
    
    public void cancelarOperacao(){
        telaConsultaView.getjButtonCancelar().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                telaConsultaView.setVisible(false);
            }
        });
    }
    
    /*public void visualizarFuncionario(){
        telaConsultaView.getjButtonVisualizar().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                telaConsultaView.setVisible(false);
                selecionarFuncionario();
                telaVisualizacaoPresenter.janelaResultado();
            }
        });
    }
    
    public void selecionarFuncionario(){
        telaConsultaView.getjTableFuncionarios().getSelectionModel().addListSelectionListener(new ListSelectionListener() {
        @Override
        public void valueChanged(ListSelectionEvent e) {
            if (!e.getValueIsAdjusting()) {
                int linhaSelecionada = telaConsultaView.getjTableFuncionarios().getSelectedRow();
                    if (linhaSelecionada >= 0) {
                        Funcionario funcionario = collection.getFuncionarios().get(linhaSelecionada);
                        telaVisualizacaoPresenter.setFuncionario(funcionario);
                    }
                }
            }
        });
    }*/

    public void configuraTabela(FuncionarioCollection collection){
        DefaultTableModel tableModel = (DefaultTableModel) telaConsultaView.getjTableFuncionarios().getModel();
        tableModel.setRowCount(0);
        for (Funcionario funcionario : collection.getFuncionarios()) {
            tableModel.addRow(new Object[]{funcionario.getNome(), funcionario.getCargo(), funcionario.getSalario()});
        }
        tableModel.fireTableDataChanged();
    }
    
}
